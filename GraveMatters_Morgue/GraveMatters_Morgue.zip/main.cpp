#include "UI.h"
#include <crtdbg.h>

int main()
{
	{
		Repository repository{};
		Repository transferred{};
		Controller controller{ repository, transferred };
		UI ui{ controller };
		ui.userInterface();
	}

	/*{
		_CrtDumpMemoryLeaks();
	}*/
	return 0;
}